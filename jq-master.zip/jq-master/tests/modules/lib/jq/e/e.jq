def bah: "bah";
